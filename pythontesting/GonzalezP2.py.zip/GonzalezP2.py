"""
Program: Project 2
Author: Bella Gonzalez
Description: Matching game
"""
from match_graphics import *

test_list = []


def shuffle_cards():
    """
    Generates a shuffled deck of cards. When done, cards[i][j] is the name
    of the card in row i and column j. It is a 5x5 grid comprised of 12
    card pairs and one extra card.



    """

    # The idea of how we shuffle is the following:
    # (1) shuffle the images
    shuffle(images)
    # (2) pick out 12 of the images (these are the ones that will be pairs)

    images_list = []
    for i in range(12):
        images_list.append(images[i])
        images_list.append(images[i])
    images_list.append(images[12])
    # (3) pick out the 'extra image' (this is the one that will have no pair)

    # (4) create a list with 2 of each pair and the extra image

    # (5) shuffle that list
    shuffle(images_list)

    #
    # use the list of these 25 shuffled cards to build a 5x5 array of cards
    cards = []
    for i in range(5):
        row = []
        for j in range(5):
            item = images_list[j + 5 * i]  # currently, array is the same card, over and over
            row.append(item)
        cards.append(row)
    return cards


def show_card(win, card_name, i, j):
    """
    Shows the card at row i and column j in the 5x5 grid in the window.
    the examples in match_graphics
    """

    #
    # Draw a rectangle with a yellow border of line width 5
    #  at the location associated with card (i,j)
    #  Ex: card (0,0) has upper-right corner (XMARGIN, YMARGIN) and
    #   lower-right corner (XMARGIN+CARD_WIDTH, YMARGIN+CARD_HEIGHT)
    x_top_left = Point(XMARGIN + CARD_WIDTH * i, YMARGIN + CARD_HEIGHT * j)
    x_bottom_right = Point(XMARGIN + CARD_WIDTH * (i + 1), YMARGIN + CARD_HEIGHT * (j + 1))
    enclosing_rectangle = Rectangle(x_top_left, x_bottom_right)
    enclosing_rectangle.setFill('light green')
    enclosing_rectangle.setOutline('yellow')
    enclosing_rectangle.setWidth(5)
    enclosing_rectangle.draw(win)

    #  at the location associated with card (i,j)
    #  Ex: card (0,0) has upper-right corner (XMARGIN, YMARGIN) and
    #   lower-right corner (XMARGIN+CARD_WIDTH, YMARGIN+CARD_HEIGHT)
    x_top_left = Point(XMARGIN * CARD_WIDTH * i, YMARGIN + CARD_HEIGHT * j)
    x_bottom_right = Point(XMARGIN * CARD_WIDTH * i, YMARGIN + CARD_HEIGHT * j)

    # Draw the image for card_name at the center of the rectangle.
    card = Image(Point(XMARGIN + CARD_WIDTH * (i + 1 / 2), YMARGIN + CARD_HEIGHT * (j + 1 / 2)), card_name)
    card.draw(win)
    return card


def hide_card(win, i, j):
    """
    Takes the window and cards and hides the card at row i and column j.


    the examples in match_graphics
    """

    win.getMouse
    x_top_left = Point(XMARGIN + CARD_WIDTH * i, YMARGIN + CARD_HEIGHT * j)
    x_bottom_right = Point(XMARGIN + CARD_WIDTH * (i + 1), YMARGIN + CARD_HEIGHT * (j + 1))
    enclosing_rectangle = Rectangle(x_top_left, x_bottom_right)
    enclosing_rectangle.setFill('light green')
    enclosing_rectangle.setOutline('yellow')
    enclosing_rectangle.setWidth(5)
    enclosing_rectangle.draw(win)
    card = enclosing_rectangle
    return card


def mark_card(win, i, j):
    """
    Takes the window and cards and marks the card at row i and column j
    with a red X.
    """

    x_top_left = Point(XMARGIN + CARD_WIDTH * i, YMARGIN + CARD_HEIGHT * j)
    x_bottom_right = Point(XMARGIN + CARD_WIDTH * (i + 1), YMARGIN + CARD_HEIGHT * (j + 1))
    line_left = Line(x_top_left, x_bottom_right)
    line_right = Line(Point(x_top_left.x + CARD_WIDTH, x_top_left.y),
                      Point(x_bottom_right.x - CARD_WIDTH, x_bottom_right.y))
    line_left.setFill('red')
    line_right.setFill('red')
    line_right.setWidth(5)
    line_left.setWidth(5)
    line_left.draw(win)
    line_right.draw(win)
    return


def get_col(x):
    """
    Takes the x-coordinate value and returns the column.
    If the x coordinate is outside the board, returns -1.


    """

    col = int((x - XMARGIN) // CARD_HEIGHT)
    if col < 0 or col > 4:
        return -1
    return col


def get_row(y):
    '''
    Takes the y-coordinate value and returns the row.
    If the y-coordinate is outside the board, returns -1.
    the examples in match_graphics
    '''

    row = int((y - XMARGIN) // CARD_HEIGHT)
    if row < 0 or row > 4:
        return -1
    return row


def is_valid(test_point):
    if test_point in test_list:
        return False
    else:
        return True


def main():
    '''
    Generates the Game window, then draws the board with the cards, Then as the user clicks the cars the main
    is testing to see if the cards match. If the cards match then the cards are shown and Xd off until the end
    of the game, if they do not match, they are hidden. When all but the odd card are chosen the background
    screen flashes multiple colors.
    '''

    # generate game window
    win = create_board()

    # shuffle the cards
    cards = shuffle_cards()

    # draw the 5x5 board with the cards on it
    for i in range(5):
        for j in range(5):
            hide_card(win, i, j)

    p = True
    while True:
        if len(test_list) == 24:
            you_won(win)
        c_point = win.getMouse()
        c_point_x = c_point.getX()
        c_point_y = c_point.getY()
        i = get_col(c_point_x)
        j = get_row(c_point_y)
        while i < 0 or j < 0:
            c_point = win.getMouse()
            c_point_x = c_point.getX()
            c_point_y = c_point.getY()
            i = get_col(c_point_x)
            j = get_row(c_point_y)

        if p:

            if not is_valid((i, j)):
                continue
            show_card(win, cards[i][j], i, j)
            old_card = cards[i][j]
            old_i = i
            old_j = j
            p = False
        else:

            if not is_valid((i, j)):
                continue
            if (old_i, old_j) == (i, j):
                continue
            show_card(win, cards[i][j], i, j)

            p = True

            game_delay(1)

            if old_card == cards[i][j]:
                mark_card(win, i, j)
                mark_card(win, old_i, old_j)
                test_list.append((i, j))
                test_list.append((old_i, old_j))


            else:
                hide_card(win, i, j)
                hide_card(win, old_i, old_j)

    win.getMouse()


main()
